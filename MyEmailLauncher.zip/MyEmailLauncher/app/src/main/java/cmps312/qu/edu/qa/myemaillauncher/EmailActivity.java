package cmps312.qu.edu.qa.myemaillauncher;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ShareCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.List;

public class EmailActivity extends AppCompatActivity {
    ImageView imageView;
    TextView subjectTextView, bodyTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email);

        imageView = (ImageView) findViewById(R.id.imageView);
        subjectTextView = (TextView) findViewById(R.id.subject_content_text_view);
        bodyTextView = (TextView) findViewById(R.id.body_content_text_view);


        Uri uri = ShareCompat.IntentReader.from(this).getStream();
        Bitmap bitmap = null;
        try {

            InputStream inputStream =
                    getContentResolver().openInputStream(uri);
            bitmap = BitmapFactory.decodeStream(inputStream);
        } catch (FileNotFoundException e) {
            Toast.makeText(this,"Chould not upload image",Toast.LENGTH_SHORT);
        }


       // ActivityCompat.requestPermissions(this);

        String text = getIntent().getStringExtra(Intent.EXTRA_TEXT);
        subjectTextView.setText(text);

        String text2 = getIntent().getStringExtra(Intent.EXTRA_TEXT);
        bodyTextView.setText(text2);

        imageView.setImageBitmap(bitmap);

    }

}
