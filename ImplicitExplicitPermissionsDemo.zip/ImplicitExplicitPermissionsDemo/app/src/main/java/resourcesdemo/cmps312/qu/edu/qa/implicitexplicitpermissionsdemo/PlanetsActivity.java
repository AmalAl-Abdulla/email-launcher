package resourcesdemo.cmps312.qu.edu.qa.implicitexplicitpermissionsdemo;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import static android.R.attr.targetActivity;
import static android.R.attr.x;

public class PlanetsActivity extends AppCompatActivity{
    public static final String PLANET_INDEX = "PLANET_INDEX";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_planet_layout);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.mipmap.solar_system);
        getSupportActionBar().setDisplayUseLogoEnabled(true);

    }
    protected void displayFacts(View view){
        int selectedPlanet=0;
        switch(view.getId()){
           case R.id.mercury: selectedPlanet=0;
               break;
           case R.id.venus:   selectedPlanet=1;
               break;
           case R.id.earth:   selectedPlanet=2;
               break;
           case R.id.mars:    selectedPlanet=3;
               break;
           case R.id.jupiter: selectedPlanet=4;
               break;
           case R.id.saturn:  selectedPlanet=5;
               break;
           case R.id.uranus:  selectedPlanet=6;
               break;
           case R.id.neptune: selectedPlanet=7;

       }
        Intent i = new Intent(PlanetsActivity.this,PlanetFactsActivity.class);
        i.putExtra(PLANET_INDEX,selectedPlanet);
        startActivity(i);

    }

}
