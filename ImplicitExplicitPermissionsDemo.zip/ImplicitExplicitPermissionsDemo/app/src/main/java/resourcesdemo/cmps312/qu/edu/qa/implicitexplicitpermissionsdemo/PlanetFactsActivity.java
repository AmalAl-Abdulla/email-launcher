package resourcesdemo.cmps312.qu.edu.qa.implicitexplicitpermissionsdemo;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import static resourcesdemo.cmps312.qu.edu.qa.implicitexplicitpermissionsdemo.R.id.email;

public class PlanetFactsActivity extends AppCompatActivity {
    public static final String TAG = PlanetFactsActivity.class.getSimpleName();
    public static final int MY_PERMISSIONS_REQUEST_READ = 202;
    int planetImageArray[] = {
            R.drawable.mercury, R.drawable.venus, R.drawable.earth,
            R.drawable.mars, R.drawable.jupiter, R.drawable.saturn,
            R.drawable.uranus, R.drawable.neptune};
    String planetFactArray[];
    TextView descTV;
    ImageView planetTv;
    Button emailButton;
    String planetFactsString;
    int planetIndex = 0;
    boolean permissionGranted = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.planet_facts_layout);
        descTV = (TextView) findViewById(R.id.factsTv);
        planetTv = (ImageView) findViewById(R.id.planetImage);
        emailButton = (Button) findViewById(R.id.email);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.mipmap.solar_system);
        getSupportActionBar().setDisplayUseLogoEnabled(true);

        planetFactArray = getResources().getStringArray(R.array.planets);
        Log.d(TAG, "ERROR HERE1");
        planetIndex = getIntent().getIntExtra(PlanetsActivity.PLANET_INDEX, 0);
        Log.d(TAG, "ERROR HERE2");
        planetFactsString = planetFactArray[planetIndex];
        descTV.setText(planetFactsString.toString());
        planetTv.setImageResource(planetImageArray[planetIndex]);
    }
    protected void nextPlanet(View view){
        planetIndex = (planetIndex+1)% planetImageArray.length;
        planetFactsString = planetFactArray[planetIndex];
        descTV.setText(planetFactsString);
        planetTv.setImageResource(planetImageArray[planetIndex]);
    }
    @Override
    protected void onNewIntent(Intent intent) { //so when the user press back it does not exist to first activity
        super.onNewIntent(intent);
        setIntent(intent);
    }

    public void sendEmail(View view) {

        int permissionCheck = ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE);

        String permissions[] = {android.Manifest.permission.WRITE_EXTERNAL_STORAGE, android.Manifest.permission.READ_EXTERNAL_STORAGE};

        if (permissionGranted || permissionCheck == PackageManager.PERMISSION_GRANTED) {
            permissionGranted=true;
            Intent i = new Intent(Intent.ACTION_SEND);
            i.putExtra(Intent.EXTRA_EMAIL, new String[]{"aa1512895@qu.edu.qa", "student__a@hotmail.com"});
            i.putExtra(Intent.EXTRA_SUBJECT, "Check this fact");
            i.putExtra(Intent.EXTRA_TEXT, planetFactsString);
            i.setData(Uri.parse("mailto:"));
            i.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(getAttachment(planetImageArray[planetIndex])));
            i.setType("text/plain");
            i.setType("image/*");
            try {
                startActivity(Intent.createChooser(i, "please choose an email client that you would like to send this information on!"));
        } catch (android.content.ActivityNotFoundException ex) {
                Toast.makeText(PlanetFactsActivity.this, "There are no email clients installed.", Toast.LENGTH_SHORT).show();
            }
            if (i.resolveActivity(getPackageManager()) != null) {
                startActivity(i);
            }
        }else{ // for first time

                Toast.makeText(this, "No permission", Toast.LENGTH_LONG).show();
                requestThisPermissions(permissions);
             }
        }


    public void requestThisPermissions(String permissions[]){ // I need for first time app run
        int permissionCheck = ContextCompat.checkSelfPermission(this, permissions[0]);
        if (permissionCheck != PackageManager.PERMISSION_GRANTED){
            if(ActivityCompat.shouldShowRequestPermissionRationale(this, permissions[0])) {
            }
                ActivityCompat.requestPermissions(this, permissions, MY_PERMISSIONS_REQUEST_READ);
        } else {
            permissionGranted = true;
        }
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults){
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_READ:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    permissionGranted = true;
                        Toast.makeText(this, "Check your email", Toast.LENGTH_LONG).show();
                } else
                    permissionGranted = false;
        }
    }



    private File getAttachment(int resId) {

        FileOutputStream outStream;
        File file;

        Bitmap bm = BitmapFactory.decodeResource(getResources(), resId);
        String extStorageDirectory = Environment.getExternalStorageDirectory().toString();
        String filename = getResources().getResourceName(planetImageArray[planetIndex]);

        filename = filename.substring(filename.lastIndexOf('/') + 1);

        Log.d("PLANET NAME ", filename);
        file = new File(extStorageDirectory, filename + ".png");
        try {
            outStream = new FileOutputStream(file);
            bm.compress(Bitmap.CompressFormat.PNG, 100, outStream);
            outStream.flush();
            outStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return file;
    }
}
